export default {
    hit: [
        "https://media.tenor.com/DCzuSR89_4AAAAAC/slap-smack.gif",
        "https://media.tenor.com/PfhcJSr-tLEAAAAd/tomoko-higashikata-jojo.gif",
        "https://media.tenor.com/1O7qwjzOh9EAAAAC/naughtyboy-spanking.gif",
        "https://media.tenor.com/Pa22o6w2a7wAAAAC/jojo-hit-face.gif",
        "https://media.tenor.com/K_oZaslZjaEAAAAC/lady-hitting-a-man-with-her-bag.gif"
    ],
    kneeldown: [
        "https://media.tenor.com/ExPiSE2Gz9QAAAAC/yes-sir.gif",
        "https://media.tenor.com/Z0n5TwjFaLQAAAAd/marriage-proposal-sloane.gif",
        "https://media.tenor.com/TCtINM7OSNIAAAAd/kneel-kneel-down.gif",
        "https://media.tenor.com/_BUtYEtMXHMAAAAC/arrodillarse-dani-martinez.gif",
        "https://media.tenor.com/EsXxS3NxLGEAAAAC/uoh-kneel.gif"
    ],
    hug: [
        "https://media.tenor.com/gOcOLipgnkoAAAAC/hug-hugs.gif",
        "https://media.tenor.com/rhM8Dnf-AyMAAAAC/caring-hug-caring-kiss.gif",
        "https://media.tenor.com/sSbr1al2-KQAAAAC/so-cute.gif",
        "https://media.tenor.com/fjyH7Yd7yG8AAAAC/k-on-hug.gif",
        "https://media.tenor.com/m_bbfF_KS-UAAAAC/engage-kiss-anime-hug.gif",
    ],
    kiss:[
        "https://media.tenor.com/6sQ3YW7Fk44AAAAC/kiss.gif",
        "https://media.tenor.com/hQhr97tc5AIAAAAC/gay-kiss.gif",
        "https://media.tenor.com/dn_KuOESmUYAAAAC/engage-kiss-anime-kiss.gif",
        "https://media.tenor.com/N1fgjwPF-B8AAAAC/kiss-sweet.gif",
        "https://media.tenor.com/-_NJcR60b7UAAAAC/anime.gif",
    ]

}