import GallowsGameModel from "../models/GallowsGame.model.js";

class GallowsGameService{

    static async startGame(message){
        const member = message.member.user;
        console.log("")
    }

}


export default GallowsGameService;